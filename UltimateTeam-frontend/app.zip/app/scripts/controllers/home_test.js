'use strict';

describe('ultimateTeam.home module', function() {

  beforeEach(module('ultimateTeam.home'));

  describe('home controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var homeCtrl = $controller('HomeCtrl');
      expect(homeCtrl).toBeDefined();
    }));

  });
});