'use strict';

describe('ultimateTeam.players module', function() {

  beforeEach(module('ultimateTeam.players'));

  describe('players controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var playersCtrl = $controller('PlayerListCtrl');
      expect(playersCtrl).toBeDefined();
    }));

  });
});